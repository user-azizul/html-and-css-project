#### Icons

(Font Awesome)[https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css]

Or there is a fallback folder in the root

#### 16 - ES6 Slider

(JS Video)[https://youtu.be/V26mqoNncO4]
<br  />

(HTML&CSS Video) [www.johnsmilga.com]
